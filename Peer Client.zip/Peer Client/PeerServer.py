import socket
import threading

HOST = '127.0.0.1'  # Lokaler Host
PORT = 12345

clients = []


def broadcast(msg, sender_socket):
    for client in clients:
        if client != sender_socket:
            try:
                client.send(msg)
            except:
                client.close()
                clients.remove(client)


def handle_client(client_socket):
    while True:
        try:
            msg = client_socket.recv(1024)
            broadcast(msg, client_socket)
        except:
            clients.remove(client_socket)
            client_socket.close()
            break


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[SERVER] Running on {HOST}:{PORT}")

    while True:
        client_socket, addr = server.accept()
        print(f"[New Connection] {addr}")
        clients.append(client_socket)
        thread = threading.Thread(target=handle_client, args=(client_socket,))
        thread.start()


start_server()
